package com.example.androidconsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast notificacion = Toast.makeText(this, "INGRESE SUS DATOS DE ACCESO", Toast.LENGTH_LONG);
        notificacion.show();
        setContentView(R.layout.activity_main);

        et1 = (EditText) findViewById(R.id.et1);
        et2 = (EditText) findViewById(R.id.et2);

    }

    public void verificar(View v) {
        String clave = et2.getText().toString();
        String usu = et1.getText().toString();

        if (clave.length() == 0) {
            Toast notificacion = Toast.makeText(this, "La clave no puede quedar vacía", Toast.LENGTH_LONG);
            notificacion.show();

        }if (usu.equals("Admin")&&clave.equals("12345")){
            Toast notificacion = Toast.makeText(this, "BIENVENIDO, SELECCIONE UNA OPCION", Toast.LENGTH_LONG);
            notificacion.show();

            Intent i = new Intent(this, inermediate.class );
            startActivity(i);

        }else{
            Toast notificacion = Toast.makeText(this, "Clave y USUARIO INGRESADOS INCORRECTAMENTE", Toast.LENGTH_LONG);
            notificacion.show();

        }
    }


}