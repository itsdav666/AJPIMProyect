package com.example.androidconsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Comunidad extends AppCompatActivity {

    private EditText idComunidad,comunidad,canton,direccion,ciAsistencia;
    private Button btnAgregar,btnBuscar,btnActualizar,btnBorrar;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comunidad);

        idComunidad=(EditText)findViewById(R.id.etId);
        comunidad=(EditText)findViewById(R.id.etComunidad);
        canton=(EditText)findViewById(R.id.etCanton);
        direccion=(EditText)findViewById(R.id.etDireccion);
        ciAsistencia=(EditText)findViewById(R.id.etAsistencia);



        btnAgregar=(Button)findViewById(R.id.btnGuardar);
        btnBuscar=(Button)findViewById(R.id.btnBuscar);
        btnActualizar=(Button)findViewById(R.id.btnActualizar);
        btnBorrar=(Button)findViewById(R.id.btnBorrar);


        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ejecutarServico("http://192.168.100.157/phpProy/insertardatosComunidad.php");
            }
        });
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscar("http://192.168.100.157/phpProy/buscardatosasistencia.php?cedula="+idComunidad.getText());
            }
        });
        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View v) {
                actualizar("http://192.168.100.157/phpProy/actualizarasistencia.php?cedula="+idComunidad.getText()+"");
            }
        });
        btnBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                borrar("http://192.168.100.157/phpProy/borrardatos.php?cedula="+idComunidad.getText()+"");
            }
        });
    }

    public void salir(View v) {
        Toast notificacion = Toast.makeText(this, "SELECCIONE UNA OPCION", Toast.LENGTH_LONG);
        notificacion.show();

        finish();

    }

    private void ejecutarServico(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String,String>();

                parametros.put("idComunidad",idComunidad.getText().toString());
                parametros.put("comunidad",comunidad.getText().toString());
                parametros.put("canton",canton.getText().toString());
                parametros.put("direccion",direccion.getText().toString());
                parametros.put("ciAsistencia",ciAsistencia.getText().toString());

                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void buscar(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        idComunidad.setText(jsonObject.getString("idComunidad"));
                        comunidad.setText(jsonObject.getString("comunidad"));
                        canton.setText(jsonObject.getString("canton"));
                        direccion.setText(jsonObject.getString("direccion"));
                        ciAsistencia.setText(jsonObject.getString("ciAsistencia"));

                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue=Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    private void actualizar(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String,String>();
                parametros.put("comunidad",comunidad.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    private void borrar(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String,String>();
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}