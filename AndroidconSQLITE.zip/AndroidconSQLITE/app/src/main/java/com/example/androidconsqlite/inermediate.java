package com.example.androidconsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class inermediate extends AppCompatActivity {
    private TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inermediate);

        tv1=(TextView) findViewById(R.id.tv1);
    }


    public void comunidad(View v){
        Intent i = new Intent(this, Comunidad.class );
        startActivity(i);
        Toast notificacion = Toast.makeText(this, "BIENVENIDO A LA SECCION DE COMUNIDAD", Toast.LENGTH_LONG);
        notificacion.show();

    }

    public void Asistencia(View v){
        Intent i = new Intent(this, Persona.class );
        startActivity(i);
        Toast notificacion = Toast.makeText(this, "BIENVENIDO A LA SECCION DE ASISTENCIA", Toast.LENGTH_LONG);
        notificacion.show();
    }
    public void salir(View v){
        Toast notificacion = Toast.makeText(this, "INGRESE LOS DATOS DE ACCESO", Toast.LENGTH_LONG);
        notificacion.show();
        finish();
    }
}